from market import app
from flask import render_template, redirect, url_for, flash, request
from market.models import Item, User
from market.forms import RegisterForm, LoginForm, PurchaseItemForm, SellItemForm,AddForm,DeleteForm,BuyForm,SellForm
from market import db
from flask_login import login_user, logout_user, login_required, current_user




@app.route('/')
@app.route('/home')
def home_page():
    return render_template('home.html')

@app.route('/market', methods=['GET', 'POST'])
@login_required
def market_page():
    purchase_form = PurchaseItemForm()
    selling_form = SellItemForm()
    delete_form=DeleteForm()
    form = AddForm()
    buy_form=BuyForm()
    sell_form=SellForm()
    if request.method == "POST":
        # form = RegisterForm()
        if form.validate_on_submit():
            p_item_object = Item(
                              name=form.name.data,
                              owner=current_user.id,
                              buy=1,
                              sell=1,
                              quantity=1)
            db.session.add(p_item_object)
            db.session.commit()
        #Sell Item Logic
        
        purchase_item = request.form.get('purchase_item')
        object = Item.query.filter_by(name=purchase_item).first()
        if object:
            object.buy(current_user)
        
        delete_item = request.form.get('delete_item')
        object = Item.query.filter_by(name=delete_item).first()
        if object:
            db.session.delete(object)
            db.session.commit()

        buy_item=request.form.get('buy_item')
        quan=buy_form.quantity.data
        object=Item.query.filter_by(name=buy_item).first()
        if object:
            object.buy=2
            object.quantity=quan
            db.session.commit()

        sell_item=request.form.get('sell_item')
        quan=sell_form.quantity.data
        object=Item.query.filter_by(name=sell_item).first()
        if object:
            object.sell=2
            object.quantity=quan
            db.session.commit()

        return redirect(url_for('market_page'))
    if request.method == "GET":
        buy_items = Item.query.filter_by(owner=current_user.id,buy=2)
        owned_items = Item.query.filter_by(owner=current_user.id,buy=1,sell=1)
        sell_items = Item.query.filter_by(owner=current_user.id,sell=2)
        print(Item.query.filter_by(buy=current_user.id))
        return render_template('market.html', buy_form=buy_form,sell_form=sell_form,delete_form=delete_form,form=form,purchase_form=purchase_form, owned_items=owned_items,buy_items=buy_items, sell_items=sell_items ,selling_form=selling_form)

@app.route('/register', methods=['GET', 'POST'])
def register_page():
    form = RegisterForm()
    if form.validate_on_submit() and form.key.data=='12345':
        user_to_create = User(username=form.username.data,
                              password=form.password1.data)
        db.session.add(user_to_create)
        db.session.commit()
        login_user(user_to_create)             
        flash(f"Account created successfully! You are now logged in as {user_to_create.username}", category='success')
        return redirect(url_for('market_page'))
    if form.errors != {}: #If there are not errors from the validations
        for err_msg in form.errors.values():
            flash(f'There was an error with creating a user:', category='danger')

    return render_template('register.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login_page():
    form = LoginForm()
    if form.validate_on_submit():
        attempted_user = User.query.filter_by(username=form.username.data).first()
        if attempted_user and attempted_user.check_password_correction(
                attempted_password=form.password.data
        ):
            login_user(attempted_user)
            flash(f'Success! You are logged in as: {attempted_user.username}', category='success')
            return redirect(url_for('market_page'))
        else:
            flash('Username and password are not match! Please try again', category='danger')

    return render_template('login.html', form=form)

@app.route('/logout')
def logout_page():
    logout_user()
    flash("You have been logged out!", category='info')
    return redirect(url_for("home_page"))

@app.route('/addRegion', methods=['POST'])
def addRegion(form):
    
    return (request.form['projectFilePath'])